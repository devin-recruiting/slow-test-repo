"""Utility functions for the slow tests demo package."""
