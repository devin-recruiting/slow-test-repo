"""Model classes for the slow tests demo package."""
