"""Integration tests for the slow tests demo package."""
